<?php 

//Ambil data isi yang ada di controller

if ($isi) {
	$this->load->view($isi);
}

?>