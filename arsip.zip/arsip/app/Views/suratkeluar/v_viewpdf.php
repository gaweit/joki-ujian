<div class="row">
    <div class="col-sm-12"></div>
    <iframe src="<?= base_url('file_surat/' . $suratkeluar['file_surat']) ?>" style="border:none;" height="800px" width="100%" title="Iframe Example"></iframe>
</div>